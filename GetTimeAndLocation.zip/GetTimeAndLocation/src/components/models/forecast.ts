export interface Forecast {
  currentTime: string
  weather: string
}
