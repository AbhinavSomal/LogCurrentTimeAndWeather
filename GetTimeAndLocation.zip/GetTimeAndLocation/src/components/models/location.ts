export interface Location {
  locationName: string
  postalCode: string
}
