# Node project using Typescript

Given an array of inputs (location name, postal code), return the current time and weather for those locations.

Using [Open Weather API](https://openweathermap.org/)

### Usage

```bash
    yarn install
```

after that

```bash
    yarn start
```
